+++
# Recent and Upcoming Talks widget.
widget = "talks"
active = true
date = 2016-04-20T00:00:00

title = "Recent & Upcoming Talks"
subtitle = ""

# Order that this section will appear in.
weight = 30

# Number of talks to list.
count = 10

# List format.
#   0 = Simple
#   1 = Detailed
list_format = 0

# Exclude talks that are shown in the Selected Talks widget?
exclude_selected = false
+++

